#########################################
#                                       #
#  UNIVERSIDADE FEDERAL DE SANTA MARIA  #
#     Manejo Florestal - CFL 1056       #
#                                       #
#########################################
#                                       #
#  Prática 10 - PMFS                    #
#                                       #
#  Prof. Gabriel A. Orso                #
#                            10/06/2026 #
#########################################



### Exercício — Seleção de árvores para exploração em um PMFS

# Utilizando os dados do Inventário Florestal a 100% da UPA 1, determine quais árvores poderiam ser selecionadas para exploração florestal.

# Considere inicialmente os seguintes critérios:

# 1. A árvore não pode pertencer a espécie protegida.
# 2. A árvore deve apresentar DAP igual ou superior ao DMC adotado para a espécie.
# 3. A árvore deve apresentar qualidade de fuste 1 ou 2.

# 4. Árvores com DAP superior a 200 cm não serão selecionadas.
# 5. Somente poderão ser exploradas espécies cuja densidade de árvores aptas seja superior a 0,03 indivíduo por hectare na respectiva UT.

# 6. Para cada espécie, deverão ser mantidas árvores remanescentes, respeitando:
# 6.1 pelo menos 10% das árvores aptas;
# 6.2 densidade remanescente mínima de 0,03 indivíduo por hectare em cada UT.

# 7. Para fins didáticos, quando for necessário escolher árvores remanescentes, deverão ser mantidos os indivíduos de maior DAP.

# Após a classificação, responda:
  
#   a) Quantas árvores foram classificadas como potencialmente aptas ao corte?
#   b) Quais espécies não puderam ser exploradas por baixa densidade?
#   c) Quantas árvores foram selecionadas para corte em cada UT?
#   d) Qual foi o volume selecionado, em m³ e m³/ha, em cada UT?
#   e) A intensidade de corte da UPA ficou abaixo de 30 m³/ha?
#   f) Compare a classificação obtida com a categoria original do inventário. Quais fatores podem explicar as divergências?
  









# 0. Carregando pacotes ----
library(tidyverse)    # tidyverse - Manipulação de dados, gráficos, etc.
library(sf)           # sf - shapefiles
library(geobr)        # pacote desenvolvido pelo IPEA para base do IBGE


# 1. Carregando dados ----
# 1.1 Propriedades ----
propriedades <- read_sf('shapefiles/APRT_Ituqui.shp')  #  Propriedades

propriedades


plot(propriedades)


# Calculando área desses polígonos
propriedades$area_prop <- st_area(propriedades)/10000
# st_area() calcula a área em m²
propriedades$area_prop <- as.numeric(st_area(propriedades))/10000




## 1.2 Reservas Legais ----
ARL <- read_sf('shapefiles/ARL_Ituqui.shp')

ARL

plot(ARL)


# Calculando área desses polígonos
ARL$area_arl <- as.numeric(st_area(ARL))/10000



# Mas será que ARL e propriedades têm a mesma ordem de geometrias?
ggplot() +
  geom_sf(data = propriedades[1,]) +
  geom_sf(data = ARL[1,], fill = 'lightblue', alpha = 0.6)

# Não! O primeiro shapefile da propriedade não bate com o primeiro shapefile da ARL

interc <- st_intersects(propriedades, ARL) 
# st_intersects faz o cruzamento dos shapes que se intersectam

interc


ARL <- ARL[as.numeric(interc), ]
ARL$Lote <- propriedades$Lote

# Conferindo
ggplot() +
  geom_sf(data = propriedades[1,]) +
  geom_sf(data = ARL[1,], fill = 'lightblue', alpha = 0.6)

ggplot() +
  geom_sf(data = propriedades) +
  geom_sf(data = ARL, fill = 'lightblue', alpha = 0.6)



# Proporção de Reserva Legal nas Propriedades
ARL$area_arl / propriedades$area_prop



## 1.3 Áreas de Manejo Florestal - AMF ----
AMF <- read_sf('shapefiles/AMF_Ituqui.shp')
AMF


AMF$area_amf <- as.numeric(st_area(AMF))/10000

# Vamos criar um data frame só com UT e áreas para facilitar
areas_UT <- st_drop_geometry(AMF[,c('UT', 'area_amf')])
names(areas_UT) <- c('UT', 'area_UT')

# Veja que AMF e propriedades estão em ordens diferentes, pois os Lotes não seguem a mesma ordem
AMF$Lote
propriedades$Lote

# Vamos arrumar AMF
AMF <- AMF[order(propriedades$Lote),]
AMF$Lote
propriedades$Lote
# Pronto


# Conferindo
ggplot() +
  geom_sf(data = propriedades[1,]) +
  geom_sf(data = ARL[1,], fill = 'lightblue', alpha = 0.6) +
  geom_sf(data = AMF[1,], fill = 'lightgreen', alpha = 0.6)
  

ggplot() +
  geom_sf(data = propriedades) +
  geom_sf(data = ARL, fill = 'lightblue', alpha = 0.6) +
  geom_sf(data = AMF, fill = 'lightgreen', alpha = 0.6)
  


## 1.4 Carregando IF ----
IF <- read_sf('shapefiles/IF_100%_TOTAL.shp')
IF

ggplot(IF) +
  geom_sf(aes(color = as.factor(Lote)))

ggplot(IF[IF$Lote=='151',]) +
  geom_sf() + 
  labs(title = 'Lote 151')



############################################################



# 2. Cálculos ----

## 2.1 Cálculos de Volumes das árvores ----
# Usaremos fator de forma 0.7
ff <- 0.7

IF$DAP <- IF$CAP/pi
IF$g <- IF$DAP^2*pi/40000  # Cálculo da área transversal
IF$v <- IF$g * IF$H * ff   # Cálculo do Volume


## 2.2 Conectando a área das UTs com o IF ----
IF2 <- left_join(IF, areas_UT, by = 'UT')
# Veja que criei IF2, uma cópia de IF, para não mexer no data frame original IF



## 2.3 Identificação das árvores inicialmente aptas ----
# Retirando Protegidas
IF2$protegida <- grepl('Bertho', IF$Cient)

# Abaixo do DMC
IF2$abaixo_DMC <- IF2$DAP < IF2$DMC

# Aptas básicas
IF2$apta_basica <- IF2$DAP >= IF2$DMC & IF2$DAP <= 200 & IF2$Fuste %in% c(1, 2) & !IF2$protegida

# Resuminho pra ver
IF2 %>% st_drop_geometry() %>% count(apta_basica)
# Aparentemente 2528 árvores aptas para corte. Não quer dizer que todas vão ser cortadas ainda



## 2.4 Densidade das árvores aptas por espécie e UT ----

densidade_especie_UT <- IF2 %>% 
  st_drop_geometry() %>% group_by(Cient, UT) %>% 
  summarise(area_UT = first(area_UT),
            N_aptas = sum(apta_basica),
            dens_aptas = N_aptas / area_UT,
            .groups = "drop") %>% 
  mutate(baixa_densidade = dens_aptas <= 0.03)

densidade_especie_UT
# As espécies onde "baixa_densidade" = TRUE não poderão ser exploradas

densidade_especie_UT %>% filter(N_aptas > 0, baixa_densidade) %>% arrange(UT, Cient)


## 2.4 Número mínimo de árvores remanescentes ----
# deve-se manter pelo menos 10% das árvores aptas para o corte, por espécie

criterios_selecao <- densidade_especie_UT %>% 
  mutate(
    N_manter_10 = ceiling(0.10*N_aptas),  # 10% das árvores aptas, arredondado pra cima
    N_manter_densidade = ceiling(0.03*area_UT),    # Piso de 0,03 árvores por hectare
    N_remanescentes = case_when(
      N_aptas == 0 ~ 0,
      baixa_densidade ~ N_aptas,  # Se a densidade já for baixa, mantém todas
      
      # Caso contrário, aplica o maior dos dois limites
      TRUE ~ pmin(N_aptas,
                  pmax(N_manter_10, N_manter_densidade))
    )
  ) 


criterios_selecao 

# Vamos manter apenas as colunas de interesse
criterios_selecao <- criterios_selecao %>% 
  select(Cient, UT, N_aptas, dens_aptas, baixa_densidade, N_remanescentes)


## 2.5 Seleção das árvores remanescentes e de corte ----
# As maiores árvores serão mantidas como remanescentes
# Na prática, vários fatores são levados em conta: distribuição espacial, sanidade, copa, e se segue um padrão de J invertido.


IF_selecao <- IF2 %>% 
  left_join(criterios_selecao, by = c('Cient', 'UT')) %>% 
  group_by(Cient, UT) %>% 
  arrange(desc(DAP), .by_group = T) %>% 
  mutate(
    ordem_apta = cumsum(apta_basica),        #Numeração somente entre árvores aptas
    Categoria = case_when(
      protegida ~ "Protegida",
      abaixo_DMC ~ "Estoque",
      DAP > 200 ~ "Não selecionada",
      !Fuste %in% c(1,2) ~ "Não selecionada",
      apta_basica & ordem_apta <= N_remanescentes ~ "Remanescente",
      apta_basica ~ "Explorar",
      TRUE ~ "Não selecionada"
    )
  ) %>% ungroup()
  


## 2.6 Árvores que seriam cortadas ----
arvores_corte <- IF_selecao %>% filter(Categoria == "Explorar")

arvores_corte

# Exportando planilha com essas árvores de corte
arvores_corte %>% st_drop_geometry() %>% 
  select(Lote, UT, Placa, Comum, Cient, DAP, H, v, Fuste, DMC) %>% 
  arrange(UT, Cient, Placa) %>% write.csv2('arvores_corte.csv', row.names = F)


# Volume selecionado por UT
resumo_UT <- arvores_corte %>% 
  st_drop_geometry() %>% 
  group_by(UT, area_UT) %>% 
  summarise(N_corte = n(), V_corte = sum(v, na.rm = TRUE),
            .groups = "drop") %>% 
  mutate(V_corte_ha = V_corte / area_UT,
         limite_30 = if_else(V_corte_ha <= 30, "Atende", 'Não atende'))

resumo_UT
# Veja que uma UT possui mais volume POSSÍVEL de ser extraído. Precisaria retirar algumas do corte.


# 3. MAPAS ----

## 3.1 Mapas das árvores selecionadas ----

ggplot() +
  geom_sf(data = AMF, fill = NA, linewidth = 0.5) +
  geom_sf(data = arvores_corte, aes(color = as.factor(UT)),
          size = 0.7) +
  labs(color = 'UT', title = 'Árvores selecionadas para exploração') +
  theme_minimal()


## 3.2 Mapa das categorias das árvores ----
ggplot(IF_selecao) +
  geom_sf(aes(color = Categoria),
          size = 0.6) +
  labs(color = "Categoria") +
  theme_minimal()





# 4. Comparando com o original ----
# Comparação com o gabarito
table(Simulada = IF_selecao$Categoria,
      Original = IF_selecao$OrCat)

# Árvores classificadas de maneira diferente e que foram exploradas em algum dos métodos
divergencias <- IF_selecao %>% 
  filter(Categoria != OrCat & (Categoria =='Explorar' | OrCat == "Explorar")) %>% 
  select(Lote, UT, Placa, Comum, Cient, DAP, Fuste, DMC,
         Categoria, OrCat)
divergencias


# Comparação com a UT 1
ut <- 3

VolOrig <- sum(IF_selecao$v[IF_selecao$OrCat == 'Explorar' & IF_selecao$UT == ut])
VolCat <- sum(IF_selecao$v[IF_selecao$Categoria == "Explorar" & IF_selecao$UT == ut])

ggplot() +
  geom_sf(data = AMF %>% filter(UT == ut)) +
  geom_sf(data = IF_selecao %>% filter(UT == ut, OrCat == "Explorar")) +
  labs(title = sprintf('Categoria Original | Volume Explorado: %.2fm³', VolOrig))

ggplot() +
  geom_sf(data = AMF %>% filter(UT == ut)) +
  geom_sf(data = IF_selecao %>% filter(UT == ut, Categoria == "Explorar")) +
  labs(title = sprintf('Categoria simulada | Volume Explorado: %.2fm³', VolCat))
