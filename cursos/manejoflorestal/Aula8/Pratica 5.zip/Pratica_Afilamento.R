#########################################
#                                       #
#  UNIVERSIDADE FEDERAL DE SANTA MARIA  #
#     Manejo Florestal - CFL 1056       #
#                                       #
#########################################
#                                       #
#  Prática 5 - Sortimentos da Madeira   #
#                                       #
#  Prof. Gabriel A. Orso                #
#                            15/04/2026 #
#########################################

# 0. Carregando pacotes ----
# install.packages('minpack.lm')
library(minpack.lm)
library(ggplot2)



# 1. Carregando dados ----
df <- read.csv2('dados_afilamento.csv')


# 2. Preparando dados ----
y <- df$di
x <- df$hi/df$ht

dap <- df$dap

# 3. Ajustando o modelo ----
# Iremos utilizar a função nlsLM(), do pacote {minpack.lm}

# Os chutes iniciais (passados no argumento start=) são muito muito importantes para a convergência
chutes_iniciais <- list(b1 = -2.94,
                        b2 = 1.37,
                        b3 = 22.25,
                        b4 = -0.17,
                        a1 = 0.2,
                        a2 = 0.59)

# Ajuste do modelo de Max-Burkhardt
mod <- nlsLM(y ~ dap*(b1*(x-1) + b2*(x^2-1) + b3*(a1-x)^2*ifelse(x<=a1,1,0) + b4*(a2-x)^2*ifelse(x<=a2, 1, 0))^0.5, 
             start = chutes_iniciais)



# Verificando o ajuste do modelo

# summary() nos dá um resumo do ajuste. 
summary(mod)

plot(y,predict(mod), main = 'Observados vs. Preditos', xlab = 'Observados', ylab = "Estimados")
abline(a = 0, b = 1, col = 2, lwd = 2)

# Histograma de Resíduos
hist(residuals(mod)) 

plot(y ~ x)
points(predict(mod) ~ x, pch = 16, col = 2)

# Parece bom!


# Agora vamos criar uma função que traça o perfil de uma árvore, para um dado DAP e H

perfil <- function(hi, ht, dap) {
  b1 <- coef(mod)[1]
  b2 <- coef(mod)[2]
  b3 <- coef(mod)[3]
  b4 <- coef(mod)[4]
  a1 <- coef(mod)[5]
  a2 <- coef(mod)[6]
  
  x <- hi/ht
  est <- dap*(b1*(x-1) + b2*(x^2-1) + b3*(a1-x)^2*ifelse(x<=a1,1,0) + b4*(a2-x)^2*ifelse(x<=a2, 1, 0))^0.5
  
  return(est)
}


plot(df$hi, df$di, main = 'Curva de Afilamento Ajustada', xlab = 'hi/h', ylab = 'di/d')
curve(perfil(hi, ht = mean(df$ht), dap = mean(df$dap)), xname='hi', add = T, col = 2, lwd = 2)


ggplot(df) + 
  geom_point(aes(x = hi, y = di)) +
  stat_function(fun=perfil, args=list(ht = mean(df$ht), dap = mean(df$dap)), mapping=aes(color='media'), linewidth=1) +
  stat_function(fun = perfil, args = list(ht = 20, dap = 20), mapping = aes(color='h20d20'), linewidth=1) +
  labs(x = 'hi (m)', y = 'di (cm)') +
  scale_color_manual(values = c('firebrick', 'steelblue'),
                     labels = c('h = 20, d = 20', 'Árvore Média'),
                     name = NULL) +
  theme_bw() + 
  theme(panel.grid = element_blank(),
        axis.text = element_text(color='black'),
        axis.title = element_text(color='black', face = 'bold'),
        legend.position = 'inside',
        legend.position.inside = c(0.98, 0.98),
        legend.justification.inside = c(1,1))



gi <- function(hi, ht, dap) {
  pi/40000 * perfil(hi, ht, dap)^2
}


# perfil() estima o diâmetro para diferentes alturas
perfil(hi = 5, ht = 20, dap = 25)

# gi() transforma esse diâmetro em área transversal
gi(hi = 5, ht = 20, dap = 25)



# Pulo do gato: Podemos integrar qualquer função numericamente.
integrate(gi, lower = 0, upper = 19, ht = 20, dap = 20)
# Integrar a função gi(), de 0 até 17m. ht = 20 e dap = 20 são a altura total e dap dessa estimativa.



# Criando função que estima o volume até hi
vi <- function(hi, ht, dap) {

  integrate(gi, lower=0, upper = hi, ht=ht, dap=dap)$value
  
}


# Estima o volume de 0 até a altura hi, para uma árvore com altura total 30 m e DAP 50 cm.
vi(hi = 20, ht = 30, dap = 50)

# Qual é o volume até a altura 15 m de uma árvore com altura total de 33m e DAP de 28 cm?
vi(hi = 15, ht = 33, dap = 28)

# Qual o volume entre 15 e 20 metros, para essa mesma árvore?
v20 <- vi(hi=20, ht = 33, dap = 28)
v15 <- vi(hi = 15, ht = 33, dap = 28)

v20-v15

# Veja que a função estima o volume tomando como referência alturas.
# Por exemplo: Qual é o volume entre alturas A e B.
# Mas é oportuno pensar "Qual seria o volume entre os DIÂMETROS A e B?"
# Para isso, precisaríamos testar diversas alturas hi usando perfil() até achar a altura que resulta nos diâmetros desejados.

# Felizmente, o R possui mecanismos para automatizar as coisas.
# est_hih() estima a altura a partir dos diâmetros. É o equivalente à inversa da função
est_hih <- function(di, ht, dap) {
  
  hih <- seq(0, 1, l=1000)
  est <- perfil(hih*ht, ht, dap)
  
  esthih <- splinefun(x = rev(est), y = hih)
  
  return(esthih(di))
}


# vi_d() estima o volume ATÉ o diâmetro di
vi_d <- function(di, ht, dap) {
  
  hi <- est_hih(di, ht, dap)*ht
  
  vi(hi=hi, ht=ht, dap=dap)
  
}

# Volume até o diâmetro de 10 cm
vi_d(di = 10, ht = 30, dap = 15)

perfil(hi = 14.17871, ht = 30, dap = 15)

vi(14.17871, ht = 30, dap = 15)
