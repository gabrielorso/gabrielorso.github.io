#########################################
#                                       #
#  UNIVERSIDADE FEDERAL DE SANTA MARIA  #
#     Manejo Florestal - CFL 1056       #
#                                       #
#########################################
#                                       #
#  Prática 7 - Fitossociologia          #
#                                       #
#  Prof. Gabriel A. Orso                #
#                            12/05/2026 #
#########################################

# 0. Pacotes Utilizados ----
library(tidyverse)
library(sf)

################################################################################

# 1. Carregando dados ----
shape <- read_sf('dados_exercicio.shp')

# Criando data frame de dados
df <- st_drop_geometry(shape)

# Retirando árvores mortas
df <- df[df$cap != 0, ]

# Retirando valores ausentes
df <- df[!is.na(df$cap), ]


################################################################################

# 2. Criando variáveis importantes ----

# Criando diâmetro e área transversal
df$d <- df$cap/pi
df$g <- df$d^2*pi/40000

# Área total
A <- 15.6 # hectares





################################################################################


# 3. Fitossociologia ----

## 3.1 Índice de Valor de Importância ----

### 3.1.1 Densidade ----
densidade <- table(df$sp)/A

densidade <- as.data.frame(densidade) # Transformando em data frame

names(densidade) <- c('sp', 'DA')

densidade$DR <- densidade$DA/sum(densidade$DA)*100



### 3.1.2 Dominância ----
dominancia <- aggregate(df$g, by = list(df$sp), FUN = sum)
names(dominancia) <- c('sp', 'DOA')
dominancia$DOA <- dominancia$DOA/A
dominancia$DOR <- dominancia$DOA/sum(dominancia$DOA)*100



### 3.1.3 Frequência ----
n_blocos <- length(unique(df$bloco))

frequencia <- as.matrix(table(df$sp, df$bloco))
frequencia <- apply(X = frequencia, MARGIN = 1, FUN = function(x) sum(x>0))/n_blocos
frequencia <- data.frame(sp = names(frequencia), FA = as.numeric(frequencia))
frequencia$FR <- frequencia$FA/sum(frequencia$FA)*100



### 3.1.4 Cálculo do IVI ----

# Juntando as Tabelas
fito <- cbind(densidade, dominancia[,-1], frequencia[,-1])
fito$IVI <- (fito$DR + fito$DOR + fito$FR)/3

fito <- fito[order(fito$IVI, decreasing = TRUE),]


head(fito)



# Gráfico de visualização
fito$sp <- factor(fito$sp, levels = rev(fito$sp))

ggplot(fito[1:10,]) +
  geom_col(aes(x = sp, y = IVI), color = 'steelblue', fill = 'steelblue',
           alpha = 0.7) +
  labs(x = 'Espécie', y = 'Índice de Valor de Importância (%)') +
  theme_bw() + 
  theme(panel.grid = element_blank(),
        axis.text = element_text(color = 'black'),
        axis.text.y = element_text(face = 'italic'),
        axis.title = element_text(color = 'black', face = 'bold')) +
  coord_flip()
  




### 3.1.5 Método Alternativo ----
# Maneira rápida com o pacote dplyr (que faz parte do tidyverse)

tab <- df %>% group_by(sp) %>% 
  summarise(DA = n()/A,
            DOA = sum(g)/A,
            FA = length(unique(bloco))/n_blocos) %>% 
  ungroup() %>% 
  mutate(DR = DA/sum(DA)*100,
         DOR = DOA/sum(DOA)*100,
         FR = FA/sum(FA)*100,
         IVI = (DR + DOR + FR)/3)


################################################################################


## 3.2 Índices de Diversidade ----

### 3.2.1 Riqueza ----

S <- length(unique(df$sp))

### 3.2.2 Índice de Shannon-Wiener ----
N <- nrow(df)
ni <- table(df$sp)

p <- ni/N


H <- -sum(p*log(p))

# Diversidade Máxima
Hmax <- log(S)



### 3.2.3 Índice de Equabilidade de Pielou ----
J <- H/Hmax



### 3.2.4 Índice de Simpson ----

D <- sum(ni*(ni-1))/(N*(N-1))

1-D
1/D


################################################################################

### 3.3 Índice de Morisita ----

# Para praticar, vamos criar uma função que recebe as quantidades de indivíduos
# por parcela, e retorna o índice de Morisita

tab_sp_bloco <- table(df$sp, df$bloco)


morisita <- function(np) {
  k <- length(np)  # k é o número de parcelas. Comprimento desse vetor np
  ni <- sum(np)  # ni é a soma dos indivíduos da espécie i
  
  numerador <- k*sum(np*(np-1))
  denominador <- ni*(ni-1)
  
  Id <- numerador/denominador
  
  return(Id)
  
}

linha1 <- tab_sp_bloco[1,]

morisita(linha1) # Parece que funciona

# Agora aplicar para todas as linhas de uma só vez


I <- apply(tab_sp_bloco, 1, morisita)




# Carregando bordas
bordas <- read_sf('borda/borda.shp')

## Objetos espaciais podem ser plotados

ggplot() + 
  geom_sf(data = bordas, fill = 'beige') +
  geom_sf(data = shape, color = ifelse(shape$cap>30, 'green', 'red')) +
  theme_classic()

