#########################################
#                                       #
#  UNIVERSIDADE FEDERAL DE SANTA MARIA  #
#     Manejo Florestal - CFL 1056       #
#                                       #
#########################################
#                                       #
#  Prática 3 - Densidade Completa e     #
#  Mortalidade                          #
#                                       #
#  Prof. Gabriel A. Orso                #
#                            01/04/2026 #
#########################################


# 1. Carregando pacotes ----
library(tidyverse)


# 2. Carregando dados ----
# df <- read.csv('dados_atividade3.csv')
df <- read.csv2('dados_atividade3.csv')

# Checando se tudo foi carregado corretamente
str(df)


# Calculando V (m³/ha)
df$V <- df$vmi * df$Narv


# 3. Criando as classes de sítio ----

plot(x = df$Idade, y = df$Hdom, 
     pch = 16, # pch é o tipo de ponto, 16 é um ponto preenchido
     main = "Título", xlab = "Eixo X", ylab = 'Eixo Y')




plot(x = 1/df$Idade, y = log(df$Hdom),
     xlab = '1/Idade', ylab = "ln(Hdom)")



lnHdom <- log(df$Hdom)
invI <- 1/df$Idade


# ln(Hdom) = b0 + b1.(1/Idade)
mod <- lm(lnHdom ~ invI)

# Estatísticas de ajuste
summary(mod)

coef(mod)

b0 <- 3.605733
b1 <- -7.700467

Syx <- 0.1246

# Fator de Correção é exp(Syx^2 / 2)
FC <- exp(Syx^2/2)

# Criando a função que estima Hdom (e não ln(Hdom))
curva_mestre <- function(idade) exp(b0 + b1*(1/idade))*FC


curva_mestre(idade = 25)
curva_mestre(10)



# Plotando a curva no gráfico
plot(df$Idade, df$Hdom, main = 'Sítio', xlab = 'Idade', ylab = "Altura Dominante (m)", pch = 16)
curve(curva_mestre, col = 'red', lwd = 2, add = T)

# Vamos fixar a idade de referência em 17 anos
Iref <- 17

abline(v = Iref, lty = 'dashed', col = 'blue', lwd = 2)


# Classes de Sítio (S) serão 18, 20, 22, 24 e 26
sitios <- c(18, 20, 22, 24, 26)

# Substituindo b0, de acordo com o método da curva-guia.
# b0 = ln(Hdom) - b1.(1/Idade). Substituímos Hdom = S e Idade = Iref, portanto
# b0 = ln(S) - b1.(1/Iref)
# Portanto Hdom = exp((ln(S) - b1.(1/Iref)) + b1.(1/Idade))
curva_geral <- function(x, S) exp(log(S) - b1/Iref + b1/x) * FC


plot(df$Idade, df$Hdom)
curve(curva_geral(x, S = 18), add = TRUE, col = 2, lwd = 2)
curve(curva_geral(x, S = 20), add = TRUE, col = 3, lwd = 2)
curve(curva_geral(x, S = 22), add = TRUE, col = 4, lwd = 2)
curve(curva_geral(x, S = 24), add = TRUE, col = 5, lwd = 2)
curve(curva_geral(x, S = 26), add = TRUE, col = 6, lwd = 2)
legend('topleft', legend = paste0('Sítio ', sitios), col = 2:6, lwd = 2)


# Criando a Tabela do Índice de Sítio
# Primeiro os limites e centros de classe
tabela_sitios <- data.frame(limites = c(17, 18, 19, 19, 20, 21, 21, 22, 23, 23, 24, 25, 25, 26, 27))

# Idades da parcelas
idades <- sort(unique(df$Idade))

# Preenchendo a tabela
for(i in idades) {
  tabela_sitios[[paste0("idade_",i)]] <- curva_geral(i, S=tabela_sitios$limites)
}

tabela_sitios <- as.data.frame(t(tabela_sitios))
rownames(tabela_sitios) <- c('S', idades)

colnames(tabela_sitios) <- paste0(c("LI_", "CC_", 'LS_'), rep(sitios, each=3))

# Tabela Pronta para ser preenchida
View(tabela_sitios)


# Exportando a tabela
write.csv2(x = tabela_sitios, file = 'tabela_sitios.csv', row.names = F)


# Classificando cada parcela em sua respectiva classe
classes <- mapply(function(hdom, t) {
  linha <- tabela_sitios[as.character(t), ]
  ifelse(hdom<linha[3], 18, ifelse(hdom<linha[6], 20, ifelse(hdom < linha[9], 22, ifelse(hdom<linha[12], 24, 26))))
}, hdom = df$Hdom, t = df$Idade)

classes

# Jogando o resultado para uma coluna dentro de "df"
df$sitios <- classes


# Criando um gráfico legal
ggplot(df) +
  geom_point(aes(x = Idade, y = Hdom, color = factor(sitios))) +
  stat_function(fun=curva_geral, args = list(S = 18), color = 2) +
  stat_function(fun=curva_geral, args = list(S = 20), color = 3) +
  stat_function(fun=curva_geral, args = list(S = 22), color = 4) +
  stat_function(fun=curva_geral, args = list(S = 24), color = 5) +
  stat_function(fun=curva_geral, args = list(S = 26), color = 6) +
  scale_color_manual(values = 2:6, name = "Sítios") +
  theme_bw() + 
  theme(panel.grid = element_blank())


# 4. Modelo de produção ----
# Várias opções de modelos

invI <- 1/df$Idade
S <- df$sitios
invS <- 1/S
G <- df$G
lnG <- log(G)

V <- df$V
lnV <- log(V)
VG <- V/G

Hdom <- df$Hdom
Hdom2 <- Hdom^2

# ln(V) = b0 + b1.S + b2.ln(G) + b3.1/Idade
clutter <- lm(lnV ~ S + lnG + invI)

hist(residuals(clutter))

summary(clutter)

plot(clutter)

# V/G = b0 + b1.Hdom + b2.Hdom^2
mod1 <- lm(VG ~ Hdom + Hdom2)

hist(residuals(mod1))
summary(mod1)

plot(mod1)


coef(mod1)

# Guardando os valores dos betas
b0 <- -3.470457999
b1 <- 0.683201305
b2 <- -0.004620372

# Veja que modelamos V/G, portanto para achar V precisamos fazer V = f(hdom).G
predV <- predict(mod1)*G


plot(Hdom, V, pch = 16)
points(Hdom, predV, pch = 16, col = 'red')
legend('topleft', legend = c('Obs', 'Est'), col = c('black', 'red'), pch = 16)


# Função para criar a curva fixando G
func_mod1 <- function(x, G) (b0 + b1*x + b2*x^2)*G

plot(Hdom, V, pch = 16)
curve(func_mod1(x, G = 50), add = T, col = 3, lwd = 2)
curve(func_mod1(x, G = 36), add = T, col = 4, lwd = 2)
curve(func_mod1(x, G = 22), add = T, col = 5, lwd = 2)
legend('topleft', legend = c('G = 50 m²/ha', 'G = 36 m²/ha', 'G = 22 m²/ha'),
       col = c(3, 4, 5), lwd = 2)

# Qual o volume de um talhão com altura dominante de 22 m e Área Basal 33 m²/ha?
func_mod1(x = 22, G = 33)


# Tarefa: Calcular a produção para as combinações de áreas basais e alturas dominantes abaixo

# G = 22, 26, 30, 34, 36, 40, 44, 48, 52
# h = 10, 12, 14, 16, 18, 20, 22, 24, 26, 28, 30



##########################################################

# Mortalidade ----
# df <- read.csv2('mortalidade_atividade3.csv')

plot(df$Idade_Anos, df$Mortalidade_Percent)

ggplot(df) +
  geom_point(aes(x = Idade_Anos, y = Mortalidade_Percent, color = Espacamento_m2))


prob <- df$Mortalidade_Percent/100

idade <- df$Idade_Anos
E <- df$Espacamento_m2

y <- log(prob/(1-prob))

mod <- lm(y ~ idade + E)

summary(mod)
hist(residuals(mod))

plinear <- predict(mod)

estimados <- exp(plinear)/(1+exp(plinear))*100

plot(df$Idade_Anos, df$Mortalidade_Percent)
points(df$Idade_Anos, estimados, pch = 16, col = 2)
