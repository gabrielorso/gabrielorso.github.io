#########################################
#                                       #
#  UNIVERSIDADE FEDERAL DE SANTA MARIA  #
#     Manejo Florestal - CFL 1056       #
#                                       #
#########################################
#                                       #
#  Prática 2 - Modelos Crescimento e    #
#  Produção                             #
#                                       #
#  Prof. Gabriel A. Orso                #
#                            25/03/2026 #
#########################################

# 0. Carregando Pacotes ----
# install.packages('tidyverse)
library(tidyverse)



# 1. Carregando dados ----
dados <- read.csv2('dados_exercicio.csv')

str(dados)


# 2. Plotando dados observados ----
plot(x = dados$Idade, y = dados$V,
     main = 'Produção', xlab = "Idade (anos)", ylab = "Produção (m³/ha)")

# Adicionando curva aproximada
A <- 400
b <- 0.08
c <- 2

chapfun <- function(x) A*(1-exp(-b*x))^c
curve(expr = chapfun, from = 0, to = 25, n = 200, add=T, lwd=2, col = 'red')



# 3. Ajustando modelo de Chapman-Richards ----

# y = f(x) = A*(1-exp(-b*x))^c
chap <- nls(V ~ A*(1-exp(-b*Idade))^c,
            data = dados, 
            start = list(A = A, b = b, c = c))


options(scipen=10)
# Estatísticas de ajuste
summary(chap)

pars <- as.numeric(coef(chap))
A <- pars[1] ; b <- pars[2] ; c <- pars[3]

# Curva ajustada
plot(x = dados$Idade, y = dados$V, main = "Produção", xlab = "Idade (anos)", ylab = "Produção (m³/ha)")
curve(expr = chapfun, from = 0, to = 25, n = 200, add=T, col = 'red', lwd=2)


# Criando um vetor de idades de 0 até 30, chamado "x"
x <- 0:30

# Produção 15 anos
chapfun(15)
chapfun(20)  # com 20 anos

chapfun(c(5, 6, 7, 8)) # Produção para os anos 5, 6, 7 e 8

prod <- chapfun(x)  # Toda produção dos anos 0 a 30, de ano em ano

# Incremento Periódico entre 10 e 13 anos
chapfun(13) - chapfun(10)

# Incremento Corrente Anual
chapfun(1) - chapfun(0)
chapfun(2) - chapfun(1)
#... Ou podemos ser mais espertos

ICA <- diff(prod)
ICA <- c(0, ICA)

# Estimativa do ICA a partir de intervalos discretos de ano em ano
plot(x, ICA, pch = 16, xlab = 'Idade (anos)', ylab = 'ICA (m³/ha/ano)',
     main = "Crescimento (ICA)")


# Estimativa do IMA é simplesmente dividindo "prod" por x
IMA <- prod/x
plot(x, IMA, pch = 16, xlab = "Idade (anos)", ylab = "IMA (m³/ha/ano)",
     main = "Crescimento (IMA)")


# Juntando os dois gráficos
plot(x, ICA, xlab = "Idade (anos)", ylab = "Crescimento (m³/ha/ano)", main = "Crescimento",
     pch = 16, col = 'steelblue')
points(x, IMA, pch = 16, col = 'firebrick')

legend('topright', legend = c('ICA', 'IMA'), pch = 16, col = c('steelblue', 'firebrick'))


# Podemos obter a mesma coisa usando a Derivada da função de produção
dchapfun <- function(x) A*b*c*exp(-b*x)*(1-exp(-b*x))^(c-1)

funcao_ima <- function(x) chapfun(x)/x

curve(dchapfun, from = 0, to = 30, n = 200, col = 'orange', lwd = 1, add = T)
curve(funcao_ima, from = 0, to = 30, n = 200, col = 'purple', lwd = 1, add = T)


##################################################################################


# 4. Ajustando o modelo de Clutter (1963) ----
# Faremos uso de Idade, Sítio (S) e área basal (G)

# Primeiro precisamos obter as classes de sítio!
# Vamos fazer pelo modelo da aula passada
mod_sitio <- nls(hdom ~ A*(1-exp(-b*Idade))^c, data = dados,
                 start = list(A=30, b = 0.11, c = 1))

mod_sitio <- lm(log(hdom) ~ I(1/Idade), data = dados)


func_sitio <- function(hdom, idade, Iref = 15, mod = mod_sitio) {
    p <- coef(mod)
    exp(log(hdom) + p[2]*(1/idade - 1/Iref))
  
}

dados$S <- func_sitio(dados$hdom, dados$Idade)

modelo <- function(x) exp(coef(mod_sitio)[1] + coef(mod_sitio)[2]/x)

curv_sitio <- function(x, hdom, Iref = 18, mod = mod_sitio) {
  p <- coef(mod)
  exp(log(hdom) + p[2]*(1/x - 1/Iref))
  
}

plot(dados$Idade, dados$hdom)
curve(modelo, add=T, from = 0, to = 20, n = 200)
curve(curv_sitio(x, hdom=20), from = 0, to = 20, n = 200, col = 2, add = T)

# O modelo é ajustado em duas etapas, sendo
# log(V2) = b0 + b1/I2 + b2*S + b3*log(B2)
# log(B2) = log(B1)*(I1/I2) + a0*(1-(I1/I2)) + a1*(1-(I1/I2))*S


# Passo 1 ----
# Primeiro precisamos ajustar a Área Basal.
# log(B2) = log(B1)*(I1/I2) + a0*(1-(I1/I2)) + a1*(1-(I1/I2))*S



dados <- dados %>% 
  group_by(Parcela) %>% 
  mutate(G2 = lead(G),
         V2 = lead(V),
         I2 = lead(Idade)
  ) %>% na.omit()

write.csv2(dados, 'teste.csv')

B1 <- dados$G
B2 <- dados$G2
V2 <- dados$V2
I1 <- dados$Idade
I2 <- dados$I2
S <- dados$S

X1 <- log(B1)*(I1/I2)
X2 <- (1-(I1/I2))
X3 <- X2*S
InvI2 <- as.numeric(1/I2)
LB2 <- log(B2)
LV2 <- log(V2)


# Ajustando o modelo
mod1 <- lm(LB2 ~ -1 + offset(X1) + X2 + X3)

summary(mod1)

PredLB2 <- fitted(mod1)


# Passo 2 ----
# Ajustando o volume
mod2 <- lm(LV2 ~ InvI2 + S + PredLB2)
summary(mod2)


## Estimando valores ----
fung <- function(B1, I1, I2, S, mod = mod1) {
  p <- coef(mod)
  exp(log(B1)*(I1/I2) + p[1]*(1-(I1/I2)) + p[2]*(1-(I1/I2))*S)
}

funv <- function(I2, S, B2, mod = mod2) {
    p <- coef(mod)
    exp(p[1] + p[2]*(1/I2) + p[3]*S + p[4]*log(B2))
  
}



# Sequencia de 1 até 30
I <- 2:30
I2 <- lead(I)

nG2 <- vector('numeric', length(I))
nG2[1] <- mean(dados$G[dados$Idade==2])

Classe_Sitio <- 25

for(i in 2:length(nG2)) {
  nG2[i] <- fung(B1=nG2[i-1], I1 = I[i-1], I2=I[i], S = Classe_Sitio)
  
}

nV2_Sitio22 <- funv(I2 = I2, S = Classe_Sitio, B2 = nG2)


plot(dados$Idade, dados$V)
points(I, nV2_Sitio22, type = 'l', col = 2)

