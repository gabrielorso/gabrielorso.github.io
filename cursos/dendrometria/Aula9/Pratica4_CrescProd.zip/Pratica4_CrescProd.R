#########################################
#                                       #
#  UNIVERSIDADE FEDERAL DE SANTA MARIA  #
#     Dendrometria - CFL1040            #
#                                       #
#########################################
#                                       #
#  Prática de Crescimento e Produção    #
#  Modelo de Chapman-Richards           #
#                                       #
#  Prof. Gabriel A. Orso                #
#                            15/06/2026 #
#########################################


# 0. Preâmbulo ----
## 0.1 alguma coisa ----
# Dentro da área de Manejo Florestal, Crescimento e Produção se refere
# à avaliação de como as variáveis de interesse (DAP, H, V etc.)
# evoluem no tempo, isto é, como essas variáveis se relacionam com a idade.
#
# Como visto em aula, o crescimento das variáveis dendrométricas pode seguir
# um comportamento conhecido, chamado comportamento sigmoidal. Nem sempre esse
# padrão ocorre de maneira perfeita, mas é uma tendência teórica importante.
#
# Podemos modelar matematicamente essa relação de diversas formas. Uma classe
# tradicionalmente usada na área é a dos modelos sigmoidais ou modelos
# biológicos, construídos para representar esse padrão de crescimento.


# 1. Modelo de Chapman-Richards ----
# Vamos utilizar o modelo de Chapman-Richards, também chamado de Richards:
#
#   Y = A * (1 - exp(-b * t))^c
#
# Em que:
#   Y = variável dependente, por exemplo volume, altura ou biomassa;
#   t = tempo ou idade;
#   A = assíntota do modelo;
#   b = parâmetro associado à taxa de crescimento;
#   c = parâmetro associado à forma da curva.
#
# O modelo é não linear, pois os parâmetros não estão em forma linear.
# Portanto, o ajuste será feito com a função nls().


# 2. Carregando os dados ----
# O arquivo dados.csv deve estar na mesma pasta deste script.
# Caso esteja em outra pasta, ajuste o caminho dentro de read.csv2().

df <- read.csv2("dados.csv")

str(df)


# O arquivo possui variáveis como:
#   Parcela: código da parcela;
#   Idade: idade do plantio;
#   d: diâmetro médio das árvores da parcela (cm);
#   h: altura média das árvores da parcela (m);
#   hdom: altura dominante da parcela (m);
#   G: área basal da parcela (m²/ha);
#   V: volume da parcela (m³/ha).


# Visualizando a relação entre idade e volume
plot(x = df$Idade,
     y = df$V,
     xlab = "Idade (anos)",
     ylab = "Volume (m³/ha)",
     main = "Relação entre Volume e Idade",
     pch = 16,
     col = "steelblue")

plot(x = df$Idade, 
     y = df$V)


# 3. Ajuste do modelo ----
# Agora vamos ajustar o modelo usando:
#
#   Y = V
#   t = Idade
#
#   V = A * (1 - exp(-b * Idade))^c
#
# O ajuste de modelos não lineares requer chutes iniciais para os parâmetros.
# Aqui, usaremos:
#   A = 550
#   b = 0.25
#   c = 4
#
# Uma relação útil é a idade do ponto de inflexão, ou idade de máximo
# crescimento instantâneo:
#
#   tmax = log(c) / b
#
# Com b = 0.25 e c = 4:

b <- 0.25
c <- 4

log(c) / b


# Criando objetos das variáveis
Y <- df$V
t <- df$Idade

# Chutes iniciais
Aini <- 550
bini <- 0.25
cini <- 4

# Ajuste do modelo com nls()
modelo <- nls(Y ~ A * (1 - exp(-b * t))^c,
              start = list(A = Aini,
                           b = bini,
                           c = cini))

# Se nenhuma mensagem de erro apareceu, o modelo foi ajustado.


# Visualizando o modelo ajustado
modelo

# Coeficientes estimados
coefs <- coef(modelo)
coefs

# Também podemos guardar os parâmetros separadamente
A <- coefs["A"]
b <- coefs["b"]
c <- coefs["c"]


# 4. Qualidade do ajuste ----

# 4.1 Erro padrão de estimativa - Syx ----
# O erro padrão de estimativa pode ser obtido pelo summary() do modelo.

summary(modelo)

# Recuperando diretamente o erro padrão residual
syx <- summary(modelo)$sigma
syx


# 4.2 Coeficiente de determinação - pseudo-R² ----
# Para modelos não lineares, uma forma comum de obter um pseudo-R²
# é elevar ao quadrado a correlação entre valores observados e preditos.

preds <- predict(modelo)

R <- cor(Y, preds)
R

R2 <- R^2
R2


# 4.3 Gráficos de resíduos ----
# Resíduo:
#
#   e = y - yhat
#
# Em R, podemos obter os resíduos com residuals().

res <- residuals(modelo)
res

# 4.3.1 Valores estimados vs. observados ----
# Esse gráfico compara os valores observados com os valores estimados.
# Em um modelo bem ajustado, os pontos devem se aproximar da reta 1:1.

plot(x = preds,
     y = Y,
     xlab = "Valores preditos",
     ylab = "Valores observados",
     main = "Observados vs. Preditos",
     pch = 16)

abline(a = 0, b = 1, col = 2)


# 4.3.2 Histograma de resíduos ----
# O histograma de resíduos ajuda a avaliar se os resíduos seguem
# aproximadamente uma distribuição normal.

hist(res,
     main = "Histograma de resíduos",
     xlab = "Resíduos")


# 5. Curva ajustada do modelo ----
# Com o modelo ajustado, podemos estimar o volume para qualquer idade:
#
#   Y = A * (1 - exp(-b * t))^c

# Criando a função Chapman-Richards com os parâmetros ajustados
chapman <- function(x) {
  A * (1 - exp(-b * x))^c
}

chapman(x = c(2, 4, 8, 15))

# Plotando pontos observados
plot(x = t,
     y = Y,
     main = "Volume em função do tempo",
     xlab = "Idade (anos)",
     ylab = "Volume (m³/ha)",
     pch = 16)

# Adicionando a curva ajustada
curve(chapman(x),
      add = TRUE,
      col = "red",
      lwd = 2)     # linewidth

legend("bottomright",
       legend = c("Observados", "Chapman-Richards"),
       pch = c(16, NA),
       lty = c(NA, 1),
       lwd = 2,
       col = c("black", "red"))


# 5.1 Idade de máximo crescimento instantâneo ----
# O ponto de inflexão da curva, ou idade de máximo incremento corrente
# instantâneo, é dado por:
#
#   tmax = log(c) / b

tmax <- log(c) / b
tmax


# 6. Crescimento ----

# 6.1 Incremento Corrente Anual - ICA observado ----
# Podemos calcular o ICA observado a partir das diferenças sucessivas de V.
# Porém, é preciso cuidado para não calcular diferenças entre parcelas
# diferentes.

head(df)
tail(df)
# Inspecionando a transição entre parcelas
df[18:25, ]


# Calculando ICA observado por diferenças sucessivas
df$ICA <- c(NA, diff(df$V))

# Retirando incrementos negativos, que podem ocorrer na troca de parcelas
df$ICA <- ifelse(test = df$ICA < 0,
                 yes = NA,
                 no = df$ICA)


# Gráfico do ICA observado em função da idade
plot(df$Idade,
     df$ICA,
     col = "firebrick",
     pch = 16,
     xlab = "Idade (anos)",
     ylab = "ICA (m³/ha/ano)",
     main = "Relação entre ICA e Idade")


# 6.2 Curva de ICA pelo modelo de Chapman-Richards ----
# A curva de crescimento é obtida pela derivada da curva de produção:
#
#   ICA = d/dt [A * (1 - exp(-b * t))^c]
#
# A derivada é:
#
#   ICA = A * b * c * (1 - exp(-b * t))^(c - 1) * exp(-b * t)

ICA <- function(x) {
  A * b * c * (1 - exp(-b * x))^(c - 1) * exp(-b * x)
}


# Plotando o ICA observado e a curva teórica de ICA
plot(df$Idade,
     df$ICA,
     pch = 16,
     xlab = "Idade (anos)",
     ylab = "ICA (m³/ha/ano)",
     main = "Relação entre ICA e Idade")

curve(ICA(x),
      add = TRUE,
      col = "firebrick",
      lwd = 2)


# 6.3 Incremento Médio Anual - IMA observado ----
# O IMA é calculado como:
#
#   IMA_t = V_t / t

df$IMA <- df$V / df$Idade

plot(df$Idade,
     df$IMA,
     pch = 16,
     main = "Relação entre IMA e Idade",
     xlab = "Idade (anos)",
     ylab = "IMA (m³/ha/ano)")


# 6.4 Curva de IMA pelo modelo de Chapman-Richards ----
# O IMA também pode ser calculado com base na curva ajustada:
#
#   IMA_t = A * (1 - exp(-b * t))^c / t

IMA <- function(x) {
  chapman(x) / x
}


plot(df$Idade,
     df$IMA,
     pch = 16,
     main = "Relação entre IMA e Idade",
     xlab = "Idade (anos)",
     ylab = "IMA (m³/ha/ano)")

curve(IMA(x),
      col = "darkgreen",
      lwd = 2,
      add = TRUE)


# 6.5 Curvas de ICA e IMA ----
# Em manejo florestal, a idade técnica de corte costuma ser associada
# ao cruzamento entre ICA e IMA, isto é, ao ponto em que o IMA é máximo.

curve(ICA(x),
      from = 2,
      to = 30,
      col = "firebrick",
      lwd = 2,
      main = "Curvas de Crescimento",
      xlab = "Idade (anos)",
      ylab = "Crescimento (m³/ha/ano)")

curve(IMA(x),
      from = 2,
      to = 30,
      col = "darkgreen",
      lwd = 2,
      add = TRUE)

legend("topright",
       legend = c("ICA", "IMA"),
       lty = 1,
       col = c("firebrick", "darkgreen"))


# 7. Máximo IMA pelo cruzamento ICA = IMA ----
# O IMA é máximo quando:
#
#   ICA = IMA
#
# Portanto, podemos encontrar a idade resolvendo a diferença ICA - IMA = 0.
# Usaremos uniroot(), que procura a raiz de uma função em um intervalo.

dif_ica_ima <- function(x) {
  ICA(x) - IMA(x)
}

idade_max_ima <- uniroot(dif_ica_ima,
                         interval = c(0.01, 100))$root

idade_max_ima

IMA_max <- IMA(idade_max_ima)
IMA_max


# Adicionando o ponto de máximo IMA ao gráfico
curve(ICA(x),
      from = 2,
      to = 30,
      col = "firebrick",
      lwd = 2,
      main = "Curvas de Crescimento",
      xlab = "Idade (anos)",
      ylab = "Crescimento (m³/ha/ano)")

curve(IMA(x),
      from = 2,
      to = 30,
      col = "darkgreen",
      lwd = 2,
      add = TRUE)

abline(v = idade_max_ima,
       lty = 2)

points(x = idade_max_ima,
       y = IMA_max,
       pch = 16)

legend("topright",
       legend = c("ICA", "IMA", "Máximo IMA"),
       lty = c(1, 1, NA),
       pch = c(NA, NA, 16),
       col = c("firebrick", "darkgreen", "black"))


# Fim do script ----
